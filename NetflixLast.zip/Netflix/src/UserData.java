import java.util.ArrayList;
import java.util.Calendar;

public class UserData {
    private ArrayList<String>users;
    private ArrayList<String>password;
    private Boolean member;
    private int [] date;


    public UserData(ArrayList<String> users, ArrayList<String> password) {
        this.users = users;
        this.password = password;
    }


    public void enterUser(String userNameInput, String passwordInput){
        for (int i=0;i<=users.size();i++){
            try {
                if (i==(users.size())){
                    System.out.println("Error! user name or password incorrect");
                    this.member=false;
                    break;
                }
                else if ((users.get(i).equals(userNameInput))&&(password.get(i).equals(passwordInput))){
                    System.out.println("Welcome back "+userNameInput);
                    this.member=true;
                    break;
                }
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
    public void newUser(String userNameInput, String passwordInput){
      users.add(userNameInput);
      password.add(passwordInput);
      System.out.println("Hello "+userNameInput+", you have registered successfully!");

    }
    public void printDate (int[]memberDate){
        this.date=memberDate;
        System.out.println();
        System.out.println("Account created on:"+date[0]+"."+date[1]+"."+date[2]);
        System.out.println("Account valid until: "+date[0]+"."+date[1]+"."+(date[2]+1));
    }

    public void memory(){

    }

    public ArrayList<String> getUsers() {
        return users;
    }

    public void setUsers(ArrayList<String> users) {
        this.users = users;
    }

    public ArrayList<String> getPassword() {
        return password;
    }

    public void setPassword(ArrayList<String> password) {
        this.password = password;
    }

    public boolean isMember() {
        return member;
    }

    public void setMember(boolean member) {
        this.member = member;
    }

    public Boolean getMember() {
        return member;
    }

    public int[] getDate() {
        return date;
    }

    public void setDate(int[] date) {
        this.date = date;
    }
}



