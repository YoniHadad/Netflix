public class AvailableContent {

    private final Episode[] romeEpisode={
            new Episode("Glory","The rise of the roman empire","1.1.20"),
            new Episode("Caesar","The reign of Julius Caesar","8.1.20"),
            new Episode("Death","End of an era,the murder of Julius Caesar","15.1.20")
    };
    private final Episode[] specialForceEpisode= {
            new Episode("Power","Police academic lets start","1.2.21"),
            new Episode("Crime","Police special force against mafia","8.2.21"),
            new Episode("Clean","Head of the police replace by the yang hero","15.2.21")
    };

    private final Episode[] goodMorningEpisode ={
            new Episode("Start","first episode of the new morning show","1.9.21"),
            new Episode("News","News and guests in our new morning show","2.9.21"),
            new Episode("Special","The hottest news with our favorite presenters","3.9.21")
    };



    private final Series rome=new Series("Rome",romeEpisode);
    private final Series specialForce=new Series("Special-force",specialForceEpisode);
    private final Series goodMorning=new Series("Good-morning",goodMorningEpisode);

    public Series getSpecialForce() {
        return specialForce;
    }
    public Series getRome() {
        return rome;
    }
    public Series getGoodMorning() {
        return goodMorning;
    }

    public Episode[] getRomeEpisode() {
        return romeEpisode;
    }

    public Episode[] getSpecialForceEpisode() {
        return specialForceEpisode;
    }

    public Episode[] getGoodMorningEpisode() {
        return goodMorningEpisode;
    }
}

