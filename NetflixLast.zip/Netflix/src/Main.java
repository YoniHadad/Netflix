import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> names = new ArrayList<>();
        ArrayList<String> passwords = new ArrayList<>();
        Map<String, String> episodeHistory = new HashMap<>();
        int []date=new int[3];
        mainMenu(names, passwords, scanner, episodeHistory,date);

    }

    public static void mainMenu(ArrayList<String> names, ArrayList<String> passwords, Scanner scanner, Map<String, String> episodeHistory,int []date) {
        System.out.println("Welcome to netflix");
        System.out.println("To open an account, press 1");
        System.out.println("To log in to an existing account, press 2");
        int userChoice = scanner.nextInt();
        UserData userData = new UserData(names, passwords);
        if (userChoice == 1) {
            date[0]= Calendar.getInstance().get(Calendar.DAY_OF_MONTH);
            date[1] = Calendar.getInstance().get(Calendar.MONTH);
            date[2] = Calendar.getInstance().get(Calendar.YEAR);
            System.out.println("Pleas enter user name: ");
            String userName = scanner.next();
            for (int i = 0; i < names.size(); i++) {
                if (names.get(i).equals(userName)) {
                    System.out.println("That user name already in used! Please try another name.");
                    mainMenu(names, passwords, scanner, episodeHistory,date);
                }
            }
            System.out.println("Pleas enter user password: ");
            System.out.println("Note! The password must be at least 6 in length and contain at least one character and one number");
            String userPassword = scanner.next();
            boolean haveNumbers = false;
            boolean haveLetter = false;
            boolean haveAtLeastSix = false;
            for (int i = 0; i < userPassword.length(); i++) {
                if (Character.isDigit(userPassword.charAt(i))) {
                    haveNumbers = true;
                }
                if (Character.isLetter(userPassword.charAt(i))) {
                    haveLetter = true;
                }
                if (userPassword.length() >= 6) {
                    haveAtLeastSix = true;
                }
            }
            if (haveAtLeastSix && haveLetter && haveNumbers) {
                userData.newUser(userName, userPassword);
                episodeHistory.put(" ", " ");
                mainMenu(names, passwords, scanner, episodeHistory,date);
            } else {
                System.out.println("Your password is not strong enough");
                mainMenu(names, passwords, scanner, episodeHistory,date);
            }

        }
        if (userChoice == 2) {
            System.out.println("Pleas enter user name: ");
            String userName = scanner.next();
            System.out.println("Pleas enter user password: ");
            String userPassword = scanner.next();
            userData.enterUser(userName, userPassword);
            if (userData.getMember()) {
                memberMenu(names,passwords,scanner, episodeHistory, userName,date,userData);

            } else {
                mainMenu(names, passwords, scanner, episodeHistory,date);
            }
        }
    }

    public static void memberMenu(ArrayList<String> names, ArrayList<String> passwords,Scanner scanner, Map<String, String> episodeHistory, String userName,int []date,UserData userData) {
        System.out.println("Press 1 for series list");
        System.out.println("Press 2 to list the series you started watching");
        System.out.println("Press 3 to view user details");
        System.out.println("Press 4 to select a series to watch");
        System.out.println("Press 5 to to logout");
        int userMenuChoice = scanner.nextInt();
        AvailableContent availableContent = new AvailableContent();
        switch (userMenuChoice) {
            case 1:
                System.out.println(availableContent.getGoodMorning().getSeriesName());
                System.out.println(availableContent.getRome().getSeriesName());
                System.out.println(availableContent.getSpecialForce().getSeriesName());
                System.out.println();
                memberMenu(names,passwords,scanner, episodeHistory, userName,date,userData);
                break;
            case 2:
                System.out.println(userName + " Watched: ");
                System.out.println("--------------------");
                for (Map.Entry entry : episodeHistory.entrySet()) {
                    System.out.println(entry.getKey());
                }
                System.out.println("--------------------");
                memberMenu(names,passwords,scanner, episodeHistory, userName,date,userData);
                break;

            case 3:
                userData.printDate(date);
                System.out.println(userName + " Watched: ");
                System.out.println("--------------------");
                for (Map.Entry entry : episodeHistory.entrySet()) {
                    System.out.println(("Series name: " + entry.getKey()) + (" episode name:" + entry.getValue()));
                }
                System.out.println("--------------------");
                memberMenu(names,passwords,scanner, episodeHistory, userName,date,userData);


                break;

            case 4:
                System.out.println("Search for a series(be sure to capitalize at the beginning of the series name):");
                String inputSeries=scanner.next();

                if ((inputSeries.equals(availableContent.getGoodMorning().getSeriesName()))||(inputSeries.equals(availableContent.getRome().getSeriesName()))||(inputSeries.equals(availableContent.getSpecialForce().getSeriesName()))) {
                    int userSeries = 0;

                    if (inputSeries.equals(availableContent.getGoodMorning().getSeriesName())){
                        userSeries=1;
                    }
                    if (inputSeries.equals(availableContent.getRome().getSeriesName())){
                        userSeries=2;
                    }
                    if (inputSeries.equals(availableContent.getSpecialForce().getSeriesName())){
                        userSeries=3;
                    }
                String watchingNow = " ";
                int userEpisode;
                if (userSeries == 1) {
                    if (episodeHistory.containsValue("Special")&&episodeHistory.containsValue("Start")&&episodeHistory.containsValue("News")){
                        System.out.println("----------------------------------------------------");
                        System.out.println("You've finished watching all the episodes of the series");
                        System.out.println("----------------------------------------------------");
                    }
                    else if (episodeHistory.containsValue("Special")){
                        System.out.println("----------------------------------------------------");
                        System.out.println("last time you watched the third episode of this show ");
                        System.out.println("----------------------------------------------------");
                    }
                    else if (episodeHistory.containsValue("News")){
                        System.out.println("----------------------------------------------------");
                        System.out.println("last time you watched the second episode of this show ");
                        System.out.println("----------------------------------------------------");
                    }
                    else if (episodeHistory.containsValue("Start")){
                        System.out.println("----------------------------------------------------");
                        System.out.println("last time you watched the first episode of this show ");
                        System.out.println("----------------------------------------------------");
                    }
                    for (Episode episode : availableContent.getGoodMorningEpisode()) {
                        System.out.println("Episode name: " + episode.getEpisodeName());
                        System.out.println("Episode summary: " + episode.getEpisodeSummary());
                        System.out.println("Episode release date: " + episode.getEpisodeReleaseDate());
                        System.out.println("----------------------------------");
                    }

                    System.out.println("Pleas choose episode by is number");
                    userEpisode = scanner.nextInt();

                    for (Episode episode : availableContent.getGoodMorningEpisode()) {
                        if (userEpisode==1&&episode.getEpisodeName().contains("Start")){
                            System.out.println("Watching now: "+episode.getEpisodeName());
                            watchingNow = episode.getEpisodeName();
                        }else if (userEpisode==2&&episode.getEpisodeName().contains("News")){
                            System.out.println("Watching now: "+episode.getEpisodeName());
                            watchingNow = episode.getEpisodeName();
                        }else if (userEpisode==3&&episode.getEpisodeName().contains("Special")){
                            System.out.println("Watching now: "+episode.getEpisodeName());
                            watchingNow = episode.getEpisodeName();
                        }

                    }
                    episodeHistory.put(availableContent.getGoodMorning().getSeriesName(), watchingNow);
                    memberMenu(names,passwords,scanner, episodeHistory, userName,date,userData);
                }

                if (userSeries == 2) {
                    if (episodeHistory.containsValue("Death")){
                        System.out.println("----------------------------------------------------");
                        System.out.println("last time you watched the third episode of this show ");
                        System.out.println("----------------------------------------------------");
                    }
                    else if (episodeHistory.containsValue("Caesar")){
                        System.out.println("----------------------------------------------------");
                        System.out.println("last time you watched the second episode of this show ");
                        System.out.println("----------------------------------------------------");
                    }
                    else if (episodeHistory.containsValue("Glory")){
                        System.out.println("----------------------------------------------------");
                        System.out.println("last time you watched the first episode of this show ");
                        System.out.println("----------------------------------------------------");
                    }
                    for (Episode episode : availableContent.getRomeEpisode()) {
                        System.out.println("Episode name: " + episode.getEpisodeName());
                        System.out.println("Episode summary: " + episode.getEpisodeSummary());
                        System.out.println("Episode release date: " + episode.getEpisodeReleaseDate());
                        System.out.println("----------------------------------");
                    }
                    System.out.println("Pleas choose episode by is number");
                    userEpisode = scanner.nextInt();

                    for (Episode episode : availableContent.getRomeEpisode()) {
                        if (userEpisode==1&&episode.getEpisodeName().contains("Glory")){
                            System.out.println("Watching now: "+episode.getEpisodeName());
                            watchingNow = episode.getEpisodeName();
                        }else if (userEpisode==2&&episode.getEpisodeName().contains("Caesar")){
                            System.out.println("Watching now: "+episode.getEpisodeName());
                            watchingNow = episode.getEpisodeName();
                        }else if (userEpisode==3&&episode.getEpisodeName().contains("Death")){
                            System.out.println("Watching now: "+episode.getEpisodeName());
                            watchingNow = episode.getEpisodeName();
                        }

                    }

                    episodeHistory.put(availableContent.getRome().getSeriesName(), watchingNow);
                    memberMenu(names,passwords,scanner, episodeHistory, userName,date,userData);
                }
                if (userSeries == 3) {
                    if (episodeHistory.containsValue("Clean")){
                        System.out.println("----------------------------------------------------");
                        System.out.println("last time you watched the third episode of this show ");
                        System.out.println("----------------------------------------------------");
                    }
                    else if (episodeHistory.containsValue("Crime")){
                        System.out.println("----------------------------------------------------");
                        System.out.println("last time you watched the second episode of this show ");
                        System.out.println("----------------------------------------------------");
                    }
                    else if (episodeHistory.containsValue("Power")){
                        System.out.println("----------------------------------------------------");
                        System.out.println("last time you watched the first episode of this show ");
                        System.out.println("----------------------------------------------------");
                    }
                    for (Episode episode : availableContent.getSpecialForceEpisode()) {
                        System.out.println("Episode name: " + episode.getEpisodeName());
                        System.out.println("Episode summary: " + episode.getEpisodeSummary());
                        System.out.println("Episode release date: " + episode.getEpisodeReleaseDate());
                        System.out.println("----------------------------------");
                    }
                    System.out.println("Pleas choose episode by is number");
                    userEpisode = scanner.nextInt();

                    for (Episode episode : availableContent.getSpecialForceEpisode()) {
                        if (userEpisode==1&&episode.getEpisodeName().contains("Power")){
                            System.out.println("Watching now: "+episode.getEpisodeName());
                            watchingNow = episode.getEpisodeName();
                        }else if (userEpisode==2&&episode.getEpisodeName().contains("Crime")){
                            System.out.println("Watching now: "+episode.getEpisodeName());
                            watchingNow = episode.getEpisodeName();
                        }else if (userEpisode==3&&episode.getEpisodeName().contains("Clean")){
                            System.out.println("Watching now: "+episode.getEpisodeName());
                            watchingNow = episode.getEpisodeName();
                        }

                    }
                    episodeHistory.put(availableContent.getSpecialForce().getSeriesName(), watchingNow);
                    memberMenu(names,passwords,scanner, episodeHistory, userName,date,userData);

                }
                }else {
                    System.out.println("It seems that the series you were looking for does not exist in our database");
                    memberMenu(names,passwords,scanner, episodeHistory, userName,date,userData);
        }

            case 5:
                System.out.println("Thank you, have a wonderful day.");
                mainMenu(names, passwords, scanner, episodeHistory,date);

        }

    }
}




